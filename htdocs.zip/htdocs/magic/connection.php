<?php session_start(); include('config.php');
	function genrandstr($num){
    $randstr="";
    $charizard="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for($i=0; $i<$num; $i++){
       $randint=rand(0,61);
        $randchar=$charizard[$randint];
        $randstr=$randstr.$randchar;
    }
    return $randstr;
}
	$myusername=$_POST['username']; 
	$mypassword=$_POST['password']; 
	$myusername = mysqli_real_escape_string($db,$myusername);
	$mypassword = mysqli_real_escape_string($db,$mypassword);
	$myusername = stripslashes($myusername);
	$mypassword = stripslashes($mypassword);
	
	$mypassword = crypt($mypassword,genrandstr(rand(10,20)));
	echo $mypassword;
	$mypassword = 
	$myusername = mysqli_real_escape_string($db,$myusername);
	$mypassword = mysqli_real_escape_string($db,$mypassword);
	
	$sql="SELECT * FROM table_ppl WHERE user='$myusername' and pass='$mypassword'";
    $result = mysqli_query($db,$sql);
	$count=mysqli_num_rows($result);
	if($count==1){
		$_SESSION['login_user'] = $myusername;
		//header("location: welcome.php");	
	}
	
         
         
	
   //echo 'ERROR: hit the back button to try again';
   
?>