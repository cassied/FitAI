<form id='login' action='connection.php' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Login</legend>
<input type='hidden' name='submitted' id='submitted' value='1'/>

<label for='user' >username*:</label>
<input type='text' name='username' id='username'  maxlength="25" />

<label for='pass' >password*:</label>
<input type='password' name='password' id='password' maxlength="30" />

<input type='submit' name='Submit' value='Submit' />

</fieldset>
</form>