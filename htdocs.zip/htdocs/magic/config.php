<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', '');
   define('DB_DATABASE', 'people');
   define('DB_TABLE', 'table_ppl');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);


   
   if(!$db){
	   die("Connection failed: ".mysqli_connect_error());
   }
   else{
	//echo"connected";
   }
   
?>