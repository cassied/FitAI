<html>
 <head>
  <title>PHP MySQL Create User Table</title>
 </head>
 <body>
 <h2>
<?php
$servername = "localhost";
$username = "dherron";
$password = "dh2350";
$dbname = "dherron";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE userinfo (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
email VARCHAR(50),
username VARCHAR(125),
password VARCHAR(20)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

 </body>
</html>


