<?php
//credentials for sql
$host="localhost";  
$dbusername="dherron";  
$dbpassword="dh2350";  
$db_name="dherron";  
$tbl_name="userinfo";

// Connect to server and select databse.
mysql_connect("$host", "$dbusername", "$dbpassword")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

if (isset($_GET['delete'])) /* checks $_GET['delete'] is set*/
     {
     if (isset($_GET['empids'])) /* checks $_GET['empids'] is set */ 
         { 
         $checkbox = $_GET['empids']; /* id is stored in $checbox variable */ 
         if (is_array($checkbox)) 
             { 
             foreach ($checkbox as $key => $your_slected_id) /* for each loop is used to get id and id is used to delete the record below */ 
                 { 
                 $del="DELETE FROM $tbl_name WHERE id=$your_slected_id "; /* Sql query to delete the records whose id is equal to $your_slected_id */
                 mysql_query($del) ; /* runs the query */ 

                 } 
                 header("location:users.php"); /* Goes back to user table.php */ 

                 } 

                 } else 
                     { 
                     echo" you have not selected reords .. to delete"; 

                     } 

                     } ?>