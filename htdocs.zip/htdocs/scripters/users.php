<!doctype html>
<html>
<head>

<!--<link href="table.css" rel="stylesheet"  type="text/css"/>-->
</head>
<body align="center">

<?php
//credentials for sql
$host="localhost";  
$dbusername="dherron";  
$dbpassword="dh2350";  
$db_name="dherron";  
$tbl_name="userinfo";

// Connect to server and select databse.
mysql_connect("$host", "$dbusername", "$dbpassword")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
 
//grab all from table userinfo
$sql="select * from userinfo ";
$res=mysql_query($sql) or die(mysql_error());

    while($rows=mysql_fetch_array($res)){
/* display the data from the database*/ 
            $display = "select * from userinfo";
        $result = mysql_query($display) or die(mysql_error()); /* the query is executed and result of the query is stored in variable $result */ 
        if ($result == FALSE) {
            die(mysql_error()); /* displays error */
	}} ?> 
		<h1 align="center"> USERS </h1> 
        <form method="get" action="delete.php" id="deleteform" > 
            <table width="245" border="1" align="center"> 
                <tr>
                    <td width="51"> Select </td>
                         
                     
                    <td width="50">id</td> 
                    <td width="55">email</td>
                    <td width="47">username</td>
                </tr>
 <?php 
 while ($rows = mysql_fetch_array($result)) 
        { /* here we make use of the while loop which fetch the data from the $result int array form and stores in $row now we can display each field from the table with $row[‘field_name’] as below */ 
     ?> 
                <tr>
                    <td>
                        <input type="checkbox" name="empids[]" value="<?php echo $rows['id']; ?>" /> <!--here with each checkbox we send the id of the record in the empids[] array ---> 
                    </td>
                    <td>
                        <?php echo $rows['id'] ?>
                    </td>
                        <td>
                            <?php echo $rows['email'] ?>
                        </td>
                        <td><?php echo $rows['username'] ?></td> 
                            <?php } ?>
                </tr>
            </table>
			
			<input align="center" type="submit" name="delete" id="button" value="delete"/> <!--- here on clicking the button the form is submitted and action is set to delete.php --->
        </form>
		<a href="rannum.php">Back to Admin tools</a>
    </body>