<?php

$host="localhost";  
$dbusername="dherron";  
$dbpassword="dh2350";  
$db_name="dherron";  
$tbl_name="userinfo";

// Connect to server and select databse.
mysql_connect("$host", "$dbusername", "$dbpassword")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// username and password sent from form 
$username=$_POST['username']; 
$password=$_POST['password']; 

// MySQL injection
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
$sql="SELECT * FROM $tbl_name WHERE username='$username' and password='$password'";
if ($username == admin && $password ==123){
session_register("admin");
header("location:rannum.php");	
}
$result=mysql_query($sql);

// Mysql_num_row is counting table row
$count=mysql_num_rows($result);

// If result matched $username and $password, table row must be 1 row
if($count==1){

// Register $username, $password and redirect to file "landing.php"
session_register("username");
session_register("password"); 
header("location:landing.php");
}
else {
echo "Wrong Username or Password";
}
?>