<!doctype html>
<html>
<head>
<link href="style.css" rel="stylesheet" title="Default Style">
</head>
<body align="center">
<?php
//redirects if not admin
session_start();
if(!session_is_registered(admin)){
header("login.php");
}

$host="localhost";  
$dbusername="dherron";  
$dbpassword="dh2350";  
$db_name="dherron";  
$tbl_name="userinfo";

// Connect to server and select databse.
session_register("winner");
mysql_connect("$host", "$dbusername", "$dbpassword")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select data");
$sql="SELECT email,username FROM $tbl_name ORDER BY RAND() LIMIT 1";
$result=mysql_query($sql);
$row = mysql_fetch_row($result);
echo'Congratulations are in order for '. $row[1] . '.'; // username
echo"their email address is " . $row[0]; // email
?>
<form name="login" method="post" action="winner.php">
email winner their code <input type="text" name="code"><br>
   <input type="submit" name="submit" value="email winner info">
   
  </form>

<?php
//emails winner details
/*
$to      = $row[1]
$subject = 'A winner has been declared' . $row[1] . 'and that is you!';
$message = 'Congratulations ' . $row[1] . '! your code is ';
$headers = 'From: idk' . "\r\n" .
    'Reply-To: idk' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
*/
?>
<br>
<a href="http://csc2.madonna.edu/~dherron/login.html" >logout</a>
</body>
</html>