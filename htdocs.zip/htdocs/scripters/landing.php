<?php
session_start();
if(!session_is_registered(winner)){
header("location:login_success.php");
}
?>

<html>
<head>
<link href="style.css" rel="stylesheet" title="Default Style">
</head>
<body align="center">
CONGRATULATIONS YOU HAVE WON! an email has been sent with the details of your victory and how to claim your prize. if you have not recieved this email please contact the admin.
<br>
<a href="http://csc2.madonna.edu/~dherron/login.html" >logout</a>
</body>

</html>