<html>
<head>
<title>REGISTERATION FORM</title>
<body>
<?php
$hostname="localhost"; 
$username="dherron";  
$password="dh2350";       
$database="dherron";  
$con=mysql_connect($hostname,$username,$password);
if(! $con)
{
die('Connection Failed'.mysql_error());
}

mysql_select_db($database,$con);

//if submit is not blanked i.e. it is clicked.
If(isset($_REQUEST['submit'])!='')
{
If($_REQUEST['username']=='' || $_REQUEST['email']=='' || $_REQUEST['password']=='')
{
Echo "fill the empty field.";
}
Else
{
$sql="insert into userinfo(email,username,password) values('".$_REQUEST['email']."', '".$_REQUEST['username']."', '".$_REQUEST['password']."')";
$res=mysql_query($sql);
If($res)
{
Echo "Record successfully inserted";
}
Else
{
Echo "ERROR INPUT";
}

}
}

?>
<br>
<a href="http://csc2.madonna.edu/~dherron/login.html" >login</a>