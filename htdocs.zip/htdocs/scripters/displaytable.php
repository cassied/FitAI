<html>
 <head>
  <title>PHP MySQL Display Table</title>
 </head>
 <body>
 <h2>
<?php
$con=mysqli_connect("localhost","dherron","dh2350","dherron");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$result = mysqli_query($con,"SELECT * FROM userinfo");

echo "<table border='1'>
<tr>
<th>email</th>
<th>username</th>
<th>password</th>
</tr>";

while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['email'] . "</td>";
  echo "<td>" . $row['username'] . "</td>";
  echo "<td>" . $row['password'] . "</td>";
  echo "</tr>";
  }
echo "</table>";

mysqli_close($con);
?> 

 </body>
</html>


