<!doctype html>
<html>
<?php
//redirects if not admin
session_start();
function verifyAdmin() {
   if(!isset($_SESSION['admin']) || $_SESSION['admin'] != 'admin'){
        header("Location: login.php");
    }
}

?>
<head>
<link href="style.css" rel="stylesheet" title="Default Style">
<!--<link href="table.css" rel="stylesheet"  type="text/css"/>-->
</head>
<h1 align="center"> ADMIN TOOLS<br> </h1>
<body align="center">
Welcome to the Admin side of things
Click submit to run the contest
<!-- This is the form that lets you enter names and how many random numbers they need -->
<form action="winner.php" method="post">
<input type="submit" name="name" maxlength="15"><br>
</form>
</body>
<br>
<a href="http://csc2.madonna.edu/~dherron/login.html" >logout</a>
<a href="users.php" >manage users</a>
</html>