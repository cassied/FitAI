#!C:/Python34/python.exe
import cgi, cgitb
import sqlite3

conn=sqlite3.connect("C:/xampp/htdocs/FITAI/fitai.db")
cursor=conn.cursor()
form=cgi.FieldStorage()

# Get data from fields
comma=', '
User="'test'"#form.getvalue('username')
Firstname="'Ad'"#form.getvalue('firstname')
Surname="'Sur'"#form.getvalue('surname')
Password="'password'"#form.getvalue('password')
cursor.execute('''INSERT INTO people(username, firstname, surname, password)
                   Values('''+User+comma+Firstname+comma+Surname+comma+Password+')')
conn.commit()                  
print("Content-Type:text/html\r\n\r\n")
print("<html>")
print("<head>")
print("<title>Successful Account Creation Page</title>")
print("</head>")
print("<body>")
print("<h2>Hello %s %s %s or should %s</h2>" % (User, Firstname, Surname,  Password))
print("</body>")
print("</html>")

