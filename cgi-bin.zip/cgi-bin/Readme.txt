In order to get python to communicate with HTML
CGI is required!

If you are using Xampp you need to put the python file (xxx.py) in the cgi Folder and copy the following code:

#!C:/Python34/python.exe
import cgi, cgitb
print("Content-Type:text/html\r\n\r\n")
print("<html>")
print("<head>")
print("<title>Hello - Second CGI Program</title>")
print("</head>")
print("<body>")
print("<h2>Hello %s %s</h2>" % (first_name, last_name))
print("</body>")
print("</html>")
#end of code

Note: the line #!C:/Python34/python.exe must be where python is stored on your computer or the server.

