#!C:/Python34/python.exe
import cgi
import cgitb

cgitb.enable()
def htmlstart():
	print(""" content-type:text/html \n \n
        <!DOCTYPE HTML>
	<html lang="en">
	<head>
	<meta charset="utf-8" />)
	<title> New user form </title>
	</head>
	<body>""")


class getData():

        def __init__(self):
                
                self.formData=cgi.FieldStorage()
                self.firstname=self.formData.getvalue('firstname')
                self.surname=self.formData.getvalue('surname')
                self.username=self.formData.getvalue('username')
                self.username=self.formData.getvalue('password')
        #START get block        
        def getfirstname(self):
                return self.firstname
        def getsurname(self):
                return self.surname
        def getusername(self):
                return self.username
        def getpassword(self):
                return self.password
        #END get block

def htmlend():
        a=getData()
        print(a.getfirstname())
        print(''' </body>
        tml>''')

htmlstart()
htmlend()
